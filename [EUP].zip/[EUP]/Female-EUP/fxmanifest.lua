fx_version 'cerulean'

games   { 'gta5' }

description 'Clothing'

lua54 'yes'